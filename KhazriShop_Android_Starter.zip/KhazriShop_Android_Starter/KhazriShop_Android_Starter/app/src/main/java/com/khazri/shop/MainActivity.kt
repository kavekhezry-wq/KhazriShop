package com.khazri.shop

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF202820)
private val Green = Color(0xFF39734A)
private val Pale = Color(0xFFF2F5EF)
private val Muted = Color(0xFF788078)

data class Product(val id: Int, val name: String, val category: String, val price: Int, val unit: String, val emoji: String)

private val sampleProducts = listOf(
    Product(1, "روغن مایع", "روغن و برنج", 89000, "بطری", "🫗"),
    Product(2, "برنج ایرانی", "روغن و برنج", 185000, "کیلو", "🍚"),
    Product(3, "رب گوجه‌فرنگی", "رب", 52000, "قوطی", "🍅"),
    Product(4, "قند شکسته", "قند", 69000, "بسته", "🧊"),
    Product(5, "شکر", "شکر", 58000, "کیلو", "🍬"),
    Product(6, "کشمش", "کشمش", 125000, "بسته", "🍇"),
    Product(7, "خرما", "خرما", 98000, "بسته", "🌴"),
    Product(8, "چای فله‌ای", "چای فله‌ای", 210000, "کیلو", "🍵"),
    Product(9, "چای بسته‌ای", "چای بسته‌ای", 145000, "بسته", "🫖"),
    Product(10, "شامپو شبنم", "بهداشت", 46000, "عدد", "🧴"),
    Product(11, "شامپو صحت", "بهداشت", 51000, "عدد", "🧴")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KhazriApp() }
    }
}

@Composable
fun KhazriApp() {
    var selectedCategory by remember { mutableStateOf("همه") }
    var search by remember { mutableStateOf("") }
    var cart by remember { mutableStateOf(mapOf<Int, Int>()) }
    var showCart by remember { mutableStateOf(false) }

    val categories = listOf("همه", "روغن و برنج", "رب", "قند", "شکر", "کشمش", "خرما", "چای فله‌ای", "چای بسته‌ای", "بهداشت")
    val visibleProducts = sampleProducts.filter {
        (selectedCategory == "همه" || it.category == selectedCategory) &&
        (search.isBlank() || it.name.contains(search.trim(), ignoreCase = true))
    }
    val count = cart.values.sum()
    val total = sampleProducts.sumOf { p -> p.price * (cart[p.id] ?: 0) }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Green, onPrimary = Color.White, background = Color(0xFFF7F8F5),
        surface = Color.White, onSurface = Ink
    )) {
        CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            if (showCart) {
                CartScreen(cart = cart, onBack = { showCart = false },
                    onRemove = { id -> cart = cart - id }, total = total)
            } else {
                Scaffold(
                    containerColor = Color(0xFFF7F8F5),
                    bottomBar = {
                        NavigationBar(containerColor = Color.White) {
                            NavigationBarItem(selected = true, onClick = { }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("خانه") })
                            NavigationBarItem(selected = false, onClick = { showCart = true }, icon = {
                                BadgedBox(badge = { if (count > 0) Badge { Text(count.toString()) } }) {
                                    Icon(Icons.Default.ShoppingCart, null)
                                }
                            }, label = { Text("سبد خرید") })
                        }
                    }
                ) { padding ->
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(padding),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Column {
                                    Text("خضری شاپ", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Green)
                                    Text("خرید روزانه، ساده و به‌صرفه", color = Muted, fontSize = 12.sp)
                                }
                                Surface(shape = CircleShape, color = Pale, modifier = Modifier.size(46.dp).clickable { showCart = true }) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.ShoppingCart, contentDescription = "سبد خرید", tint = Green)
                                    }
                                }
                            }
                        }
                        item {
                            Surface(color = Green, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("خرید آسان از خضری", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(5.dp))
                                    Text("کالاهای مورد نیازت را سریع پیدا کن", color = Color.White.copy(alpha = .88f), fontSize = 13.sp)
                                }
                            }
                        }
                        item {
                            OutlinedTextField(
                                value = search, onValueChange = { search = it },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("جست‌وجوی کالا...") },
                                leadingIcon = { Icon(Icons.Default.Search, null) },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp)
                            )
                        }
                        item {
                            Text("دسته‌بندی کالاها", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Ink)
                            Spacer(Modifier.height(9.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(categories) { category ->
                                    FilterChip(
                                        selected = selectedCategory == category,
                                        onClick = { selectedCategory = category },
                                        label = { Text(category) }
                                    )
                                }
                            }
                        }
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("محصولات", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                Text("${visibleProducts.size} کالا", color = Muted, fontSize = 12.sp)
                            }
                        }
                        items(visibleProducts) { product ->
                            ProductRow(product = product, quantity = cart[product.id] ?: 0,
                                onAdd = { cart = cart + (product.id to ((cart[product.id] ?: 0) + 1)) })
                        }
                        if (visibleProducts.isEmpty()) {
                            item { Text("کالایی پیدا نشد.", modifier = Modifier.fillMaxWidth().padding(24.dp), textAlign = TextAlign.Center, color = Muted) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProductRow(product: Product, quantity: Int, onAdd: () -> Unit) {
    Surface(color = Color.White, shape = RoundedCornerShape(16.dp), shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Pale, shape = RoundedCornerShape(12.dp), modifier = Modifier.size(58.dp)) {
                Box(contentAlignment = Alignment.Center) { Text(product.emoji, fontSize = 27.sp) }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(product.name, fontWeight = FontWeight.Bold, color = Ink)
                Text("هر ${product.unit}", color = Muted, fontSize = 11.sp)
                Text("${"% ,d".format(product.price).replace(" ", "")} تومان", color = Green, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            FilledIconButton(onClick = onAdd, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Green)) {
                Icon(Icons.Default.Add, contentDescription = "افزودن")
            }
            if (quantity > 0) {
                Text(quantity.toString(), modifier = Modifier.padding(start = 7.dp), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun CartScreen(cart: Map<Int, Int>, onBack: () -> Unit, onRemove: (Int) -> Unit, total: Int) {
    Column(Modifier.fillMaxSize().background(Color(0xFFF7F8F5)).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "بازگشت") }
            Text("سبد خرید", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        if (cart.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("سبد خریدت هنوز خالی است.", color = Muted)
            }
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(cart.keys.toList()) { id ->
                    val p = sampleProducts.first { it.id == id }
                    Surface(color = Color.White, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(p.emoji, fontSize = 25.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Bold)
                                Text("${cart[id]} عدد/واحد", color = Muted, fontSize = 12.sp)
                            }
                            Text("${(p.price * (cart[id] ?: 0)).toString()} تومان", color = Green, fontWeight = FontWeight.Bold)
                            IconButton(onClick = { onRemove(id) }) { Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color(0xFFB34B43)) }
                        }
                    }
                }
            }
            Divider()
            Spacer(Modifier.height(14.dp))
            Text("جمع تقریبی: ${total} تومان", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Button(onClick = { }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                Text("ادامه و ثبت سفارش")
            }
            Text("ثبت سفارش در این نسخه نمایشی فعال نیست.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}
